KEVIN COMPANION — 0.2.6 PREVIEW
Windows • Single-player • Subsistence Alpha 68.19

START HERE
https://github.com/SimpleNeb/Subsistence-Kevin
Click DOWNLOAD KEVIN SETUP at the top. No GitHub account is needed.

1. Subscribe to the same Kevin Workshop item:
   https://steamcommunity.com/sharedfiles/filedetails/?id=3816609201
2. Close Subsistence completely.
3. Open the NEW Kevin Setup from Downloads. Check its game folder. Use Browse
   to select the Subsistence folder containing Binaries and UDKGame if needed.
   Steam Library → right-click Subsistence → Manage → Browse local files finds it.
4. Click Install / Update and wait for “Kevin installed”.
5. Launch Subsistence, choose your single-player profile, open Mods, select
   Kevin Companion, then start or continue that profile.
6. Go outside onto clear ground. Kevin joins you when a safe place is available.

Subscribe AND run Setup. Subscription alone does not install the companion code.
For every update, download the new Setup, close the game and Install / Update
again. Keep your subscription. An old Setup installs its old version.

INSTALL FROM THIS COMPLETE ZIP
Close the game and extract the entire archive. Double-click Install Kevin.cmd.
Then select Kevin Companion in the profile's Mods list and load the profile.
Keep the extracted folder for Disable Kevin.cmd. Setup is recommended if you
need a folder picker. The repository's Code / Download ZIP is a different file.
No Python, compiler, SDK or account login is needed. This ZIP is not a way around
a Windows or antivirus security block.

GAMEPLAY INCLUDED FROM 0.2.5
Loot Boxes opens ordinary surface ammo, medical and building-supplies crates.
Scrap Metal collects native surface scrap.
Gather All includes eligible boxes and pickups such as fiber and berries; it
does not chop trees. Gather Wood remains the separate axe-based job.
Kevin takes actual items that fit, leaving other items in the original box.
No player/base/death/locked boxes, cave loot or underwater resources.
Dropped items, loose arrows and planted crops are excluded. After making cargo
room, issue the gathering command again to revisit leftovers.
A wider search lets Kevin look farther for work and continue around his new
position. Stay nearby; distance, terrain and full cargo can stop him.
Hunting bows and recurve bows use supplied ordinary or premium arrows for
defense. Select that arrow type before giving the bow; Kevin does not switch
the selection. No grenade arrows or explosive/incendiary ammunition.
Swimming and entering or interacting with your base remain deferred.

CONTROLS AND BELONGINGS
Stand close + Use: inventory. Crouch close + Use: commands.
Commands: 1 Follow, 2 Stay, 3 Inventory, 4 Wood, 5 Fiber, 6 Loot Boxes,
7 Scrap Metal, 8 Gather All. Click, number keys, or arrows + Enter.
Kevin has 35 cargo slots, 7 toolbelt slots and 6 clothing slots. Drag items into
him; shift-click into Kevin is disabled. Drag or shift-click items back out.
Put clothing in matching slots. Wood needs a usable axe. Ammo and tools are finite.
Put weapons/axes on the toolbelt, or leave one belt slot free to equip from cargo.

Close other menus, press F6, then click RECALL KEVIN on the upper-right HUD.
F6, Escape or right-click cancels the cursor. Living recall preserves health
and belongings. Dead recall returns Kevin at half health with empty inventory;
his gear stays in his original death bag. Recall cancels work and resumes Follow.
A living player and safe outdoor ground nearby are required.
Stand + Use on his bag to loot it; crouch + Use to revive him. He can also return
after about two minutes while the world runs. Gear is never copied from the bag.

DISABLE AND SAVE COMPATIBILITY
For one profile, remove Kevin from its Mods selection. Globally, close the game
and use Disable Kevin in Setup or Disable Kevin.cmd from this complete ZIP.
Keep the game's .KevinLoader folder and KevinCompanion.u while you have Kevin
saves. They hold original-file backups/install records and saved-class support.
Installer operations do not rewrite your saves. Give work orders again on load.

IF WINDOWS OR ANTIVIRUS BLOCKS IT
Setup is unsigned. Smart App Control can block it and has no individual-app
exception. Keep protection enabled; do not add an exclusion. Report the exact
warning, security product, detection name and Setup version. One clean scan does
not settle another product's detection. Microsoft explains Smart App Control:
https://support.microsoft.com/en-us/windows/security/threat-malware-protection/smart-app-control-frequently-asked-questions

If Setup opens but says the game folder denies access, Retry as administrator
requests folder permission; it does not fix a security block. For other failures,
use Save setup report, removing personal folder names before posting publicly.
Do not force installation over a game-version/checksum mismatch.
https://github.com/SimpleNeb/Subsistence-Kevin/issues

Read PLAYER-GUIDE.txt for equipment, work, recall and save details; VALIDATION.txt
describes this build's actual checks. CHECKSUMS.sha256 identifies exact files.
This is a controlled single-player preview, not an exhaustive public playtest.
Following/work/recall need suitable surface terrain. Multiplayer, building jobs
and direct player control are not included. Original game files and SDK are not
distributed. You need your own supported game. Unofficial; created by SimpleNeb.

INSTALLER DIAGNOSTICS UPDATE
0.2.6 keeps the exact 0.2.5 companion code and patches. Failed file checks now
include expected/actual SHA256 and byte lengths, with recovery guidance.
Back up saves and preserve .KevinLoader before repair. If Kevin is already
installed, preserve its records and report the mismatch before changing files.
For a fresh install, restore a verified original or use Steam > Properties >
Installed Files > Verify integrity, then retry. Verification can replace other
mods; never force a patch or replace a checksum to accept unknown game files.