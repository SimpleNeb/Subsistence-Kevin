KEVIN COMPANION — 0.2.4 PREVIEW
Windows • Single-player • Subsistence Alpha 68.19

THE SIMPLE INSTALLER
https://github.com/SimpleNeb/Subsistence-Kevin
Click DOWNLOAD KEVIN SETUP at the top of the page. No GitHub account is needed.

1. Subscribe to the Workshop item:
   https://steamcommunity.com/sharedfiles/filedetails/?id=3816609201
2. Close Subsistence completely.
3. Open the downloaded Kevin Setup. Check the Subsistence folder it found.
   If needed, Browse to the main game folder containing Binaries and UDKGame.
   Steam Library → right-click Subsistence → Manage → Browse local files finds it.
4. Click Install / Update and wait for “Kevin installed”.
5. Launch Subsistence. Choose your single-player profile, open its Mods list,
   select Kevin Companion, then start or continue that profile.
6. Go outside onto open ground. Kevin joins you when a safe place is available.
   There is no recruitment quest or special map location.

Subscribe AND run Setup. Both are required. Steam subscription alone does not
install Kevin's companion code. For every update, download the NEW Setup, close
the game, and choose Install / Update again. Keep the same Workshop subscription.

INSTALL FROM THIS ZIP
If you deliberately downloaded this complete installer ZIP instead of Setup:
1. Close Subsistence and extract the ENTIRE archive to a folder.
2. Double-click Install Kevin.cmd in the extracted folder. The installer locates
   your Steam game and checks the supported files before changing them.
3. Launch the game, select Kevin Companion in the profile's Mods list, then load
   that profile and move onto clear outdoor ground.
Keep the full extracted folder for Disable Kevin.cmd. Setup is recommended if
you need help selecting the game folder. The ZIP is not a security-block workaround.
No Python, compiler, SDK or account login is required to install Kevin.

NEW IN THIS UPDATE
An upper-right HUD button recalls Kevin, including after death. Press F6 to free
the cursor and click RECALL KEVIN. Living Kevin keeps his health and belongings;
dead Kevin returns at half health with empty inventory and his gear stays in the
original death bag. Recall resumes Follow and stops gathering. It requires a
safe place near the living player on outdoor surface ground.

The firearm-transfer problem is fixed, including native flashlight attachments.
Drag guns into Kevin's toolbelt and give him matching ordinary ammunition.
Select a supported ammo type on the gun first; Kevin does not switch ammo types.
The wider gathering search and prior installer repairs are included.

QUICK CONTROLS
Stand near Kevin + normal Use key: inventory.
Crouch near Kevin + Use: Follow, Stay, Inventory & Equipment, Wood or Fiber.
Close other menus, F6, then click RECALL KEVIN: recall beside you.
F6, Escape or right-click: cancel the recall cursor.
Stand near death bag + Use: loot. Crouch near bag + Use: revive.

Give him a usable axe for wood; fiber needs no tool. Stay nearby while he works.
He has 35 cargo slots, seven toolbelt slots and six clothing slots. Drag items
into Kevin; shift-click into Kevin is disabled. Equipment, ammo and axe condition
are finite. Put clothes in their matching slots. Supported guns: M9, Red9, M37,
double-barrel shotgun, rifle, lever-action rifle and revolver. Read the full
PLAYER-GUIDE.txt for matching ammo, attachments, jobs and revival behavior.

DISABLE AND SAVE COMPATIBILITY
For one profile, remove Kevin Companion from that profile's Mods selection.
For every profile, close the game and choose Disable Kevin in Setup, or run
Disable Kevin.cmd from this extracted ZIP. This restores the original startup
files while retaining Kevin's compatibility package, mod entry and belongings.

Keep the game's .KevinLoader folder and KevinCompanion.u while you have Kevin
saves. The first contains original-file backups and the install record; the
second supplies the classes those saves use. The installer does not rewrite saves.

IF WINDOWS OR ANTIVIRUS BLOCKS IT
Stop and report the exact warning, security product, detection name and Setup
version. Kevin Setup is unsigned. Smart App Control can block unsigned apps and
has no individual-app exception. This remains a distribution limitation.
Do not disable protection or add an exclusion to install Kevin. A clean scan
from one security product does not settle another product's detection.
Microsoft's explanation:
https://support.microsoft.com/en-us/windows/security/threat-malware-protection/smart-app-control-frequently-asked-questions

IF SETUP OPENS BUT DOES NOT FINISH
Close the game and check the selected folder. For game-folder access denied,
choose Retry as administrator and approve the Windows permission prompt if you
want to allow installation. This does not resolve a security block.

For a version/checksum mismatch, keep the backups and save the error report.
Do not force installation over files that differ from the supported game build.
Use Save setup report… for other failures. If Setup never opens, capture the
warning instead. Reports include local folder paths; remove personal information
before posting them publicly at https://github.com/SimpleNeb/Subsistence-Kevin/issues

LIMITS AND CONTENTS
Standalone single-player only. Movement, gathering and recall need suitable
outdoor surface terrain. Bases, caves and obstacles remain limitations.
Multiplayer, building jobs, bow attacks and direct player control of Kevin are
not included. This preview has not had a long public playtest of every situation.

PLAYER-GUIDE.txt explains gameplay and installation. VALIDATION.txt describes
the included build's checks. CHECKSUMS.sha256 identifies the exact release files.
This ZIP contains companion code, installer scripts and compact patches, not
the original game. You need your own installed copy of the supported game.
Kevin is unofficial and is not affiliated with Subsistence's developer.
