KEVIN COMPANION - 0.2.1 PREVIEW
For Subsistence Alpha 68.19, Windows, single-player

Kevin is a friendly companion who follows you, carries supplies, wears equipment,
defends against immediate threats, and gathers nearby wood or fiber. Kevin has
a command menu and a choice of manual revival or delayed automatic return.

INSTALL FROM THIS ZIP
1. Close Subsistence and extract the entire ZIP to a folder.
2. Double-click "Install Kevin.cmd". The installer finds your Steam game folder
   and checks the supported game files before making changes.
3. Start Subsistence. Select Kevin Companion in the profile's Mods list, then
   start or continue that profile. Kevin needs no recruitment quest.

For a game-folder picker, use Kevin Setup from the project's downloads and
choose Browse if it cannot find your installed game automatically.

This ZIP installs locally and needs no Python, compiler, SDK, or account login.
Keep the complete extracted folder for its disable tool. A Workshop subscription
alone does not install the companion code; the local installer is required.

When first enabled, Kevin appears at a safe outdoor spot near you. Continuing a
world restores his saved location, belongings, health and follow/stay order.

COMMANDS
Stand near Kevin and press the game's usual Use key to open his inventory.
Crouch and press Use to open his command menu:
  Follow Me
  Stay Here
  Inventory & Equipment
  Gather Wood
  Gather Fiber
Choose with the mouse, keys 1-5, or arrow keys and Enter. Escape or right-click
closes the menu. The menu also closes if either of you takes damage.

BELONGINGS AND DEFENSE
Kevin has 48 usable slots: 35 cargo, seven toolbelt slots and six clothing slots.
Drag items into or out of his inventory. Shift-transfer into Kevin is disabled;
shift-clicking items out works when your inventory has room. Items with their
own storage cannot be placed in his inventory.

Give him a supported firearm and its normal ammunition. He uses the ammunition
you provide and reloads from his carried reserves. Supported firearms are M9,
Red9, M37, double-barrel shotgun, rifle, lever-action rifle and revolver. Use 9mm
for M9/Red9, shells for M37, shells or slugs for the double-barrel, rifle rounds
for either rifle, and .44 rounds for the revolver. Explosive, incendiary and
other ammunition combinations are not used for defense. Clothing and armor
belong in their matching slots; their condition is retained with his belongings.

GATHERING
Gather Wood requires a usable axe in Kevin's cargo or toolbelt. Chopping wears
the axe and follows the game's tree-depletion record. Gather Fiber needs no tool
and consumes actual nearby plants. Stay near Kevin while he works. Gathering
stops if cargo is full, resources are unavailable, the route is blocked, or the
job becomes unsafe. Give a new order to change jobs. Jobs do not resume after
reloading, revival or a combat interruption; issue the order again.

IF KEVIN DIES
His equipment stays in the bag where he fell. Stand and use the bag to loot it.
Crouch and use the bag to revive Kevin nearby, or wait about two minutes while
the world is running for him to return near you on safe outdoor ground. If no
safe position is found, return waits until one is available. Kevin returns with
half health and an empty inventory. Recover and re-equip his belongings from the
original bag.

Saving and quitting retains the remaining return time. Disabling Kevin or being
dead yourself pauses the countdown. Ordinary loot-bag expiry still applies, so
collect valuable belongings promptly.

DISABLE OR UPDATE
For one profile, remove Kevin Companion from that profile's Mods selection.
For every profile, close the game and double-click "Disable Kevin.cmd". This
restores the original startup files while retaining Kevin's compatibility
package, mod entry and saved belongings. Run "Install Kevin.cmd" to enable him
again or install this release over the supported 0.1.0 or 0.2.0 preview.

Keep the game's .KevinLoader folder: it contains original-file backups and the
installation record. Do not delete KevinCompanion.u from a game with Kevin saves.
Disabling is supported; permanently removing his saved classes is not. The
installer and disable tool do not rewrite save files.

PREVIEW LIMITS
Standalone single-player only. Multiplayer, building jobs and direct control of
Kevin as the player character are not included. Movement and gathering are for
outdoor surface terrain; following pauses around bases and caves. Kevin does not
teleport to catch up. Terrain and obstacles may require repositioning or a new
order. This preview has not had a long public playtest across every terrain,
enemy, weapon or combination of mods.

The installer refuses unsupported game versions or conflicting file changes.
After a game update, use a Kevin release that supports the new game build.
Read PLAYER-GUIDE.txt for the player guide and VALIDATION.txt for the included
build's completed checks. CHECKSUMS.sha256 lists the release file checksums.

Kevin is an unofficial community mod and is not affiliated with Subsistence's
developer. Subsistence and its original assets belong to their respective owners.
This ZIP contains companion code, installer scripts and compact patches; you
need your own installed copy of the supported game.

WORKSHOP LINK
https://steamcommunity.com/sharedfiles/filedetails/?id=3816609201
Version 0.2.1 links the local installation to this Workshop item. It uses the
same companion gameplay code as version 0.2.0. Run Install / Update when upgrading.
The installer is still required; subscribing alone does not install the code.
