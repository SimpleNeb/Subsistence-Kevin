KEVIN COMPANION - 0.2.3 PREVIEW
For Subsistence Alpha 68.19, Windows, single-player

Kevin is a friendly companion who follows you, carries supplies, wears equipment,
defends against immediate threats, and gathers nearby wood or fiber. Kevin has
a command menu and a choice of manual revival or delayed automatic return.

NEW IN 0.2.3
This update improves installation on another Windows PC. Setup offers Retry as
administrator if Windows denies access to the game folder, keeps your selected
folder when restarting, and saves a report when installation needs help. The
installer also handles accented and other non-English game-folder names
correctly when reading its installation record.

Kevin's gameplay is unchanged from 0.2.2, including the wider gathering search.

WIDER GATHERING SEARCH
Kevin searches 2.5 times farther for wood and fiber. Each time he chooses his next
resource, he searches around his current position, helping him work through nearby
patches without stopping at the edge of the original search area.

INSTALL FROM THIS ZIP
1. Close Subsistence and extract the entire ZIP to a folder.
2. Double-click "Install Kevin.cmd". The installer finds your Steam game folder
   and checks the supported game files before making changes.
3. Start Subsistence. Select Kevin Companion in the profile's Mods list, then
   start or continue that profile. Kevin needs no recruitment quest.

For the simplest installation, use Kevin Setup from the project's downloads.
Choose Browse if it cannot find your installed game automatically. If Setup
shows Retry as administrator, click it and approve the Windows permission prompt
to continue. Ordinary writable game folders do not need administrator access.

If the ZIP's command window reports access denied, close it and right-click
Install Kevin.cmd, then choose Run as administrator. Kevin Setup provides this
retry in its window and is recommended if you need help finding the game.

This ZIP installs locally and needs no Python, compiler, SDK, or account login.
Keep the complete extracted folder for its disable tool. A Workshop subscription
alone does not install the companion code; the local installer is required.

When first enabled, Kevin appears at a safe outdoor spot near you. Continuing a
world restores his saved location, belongings, health and follow/stay order.

COMMANDS
Stand near Kevin and press the game's usual Use key to open his inventory.
Crouch and press Use to open his command menu:
  Follow Me
  Stay Here
  Inventory & Equipment
  Gather Wood
  Gather Fiber
Choose with the mouse, keys 1-5, or arrow keys and Enter. Escape or right-click
closes the menu. The menu also closes if either of you takes damage.

BELONGINGS AND DEFENSE
Kevin has 48 usable slots: 35 cargo, seven toolbelt slots and six clothing slots.
Drag items into or out of his inventory. Shift-transfer into Kevin is disabled;
shift-clicking items out works when your inventory has room. Items with their
own storage cannot be placed in his inventory.

Give him a supported firearm and its normal ammunition. He uses the ammunition
you provide and reloads from his carried reserves. Supported firearms are M9,
Red9, M37, double-barrel shotgun, rifle, lever-action rifle and revolver. Use 9mm
for M9/Red9, shells for M37, shells or slugs for the double-barrel, rifle rounds
for either rifle, and .44 rounds for the revolver. Explosive, incendiary and
other ammunition combinations are not used for defense. Clothing and armor
belong in their matching slots; their condition is retained with his belongings.

GATHERING
Gather Wood requires a usable axe in Kevin's cargo or toolbelt. Chopping wears
the axe and follows the game's tree-depletion record. Gather Fiber needs no tool
and consumes actual nearby plants. His search moves with him as he works, within
a limited distance of you. Stay near Kevin while he works. Gathering stops if
cargo is full, his axe is unusable, no reachable resources remain in range, or
the job becomes unsafe. Terrain can still block access. If he stops and follows
you, move near another patch and give the gathering order again. Give a new order
to change jobs. Jobs do not resume after reloading, revival or a combat
interruption; issue the order again.

IF KEVIN DIES
His equipment stays in the bag where he fell. Stand and use the bag to loot it.
Crouch and use the bag to revive Kevin nearby, or wait about two minutes while
the world is running for him to return near you on safe outdoor ground. If no
safe position is found, return waits until one is available. Kevin returns with
half health and an empty inventory. Recover and re-equip his belongings from the
original bag.

Saving and quitting retains the remaining return time. Disabling Kevin or being
dead yourself pauses the countdown. Ordinary loot-bag expiry still applies, so
collect valuable belongings promptly.

DISABLE OR UPDATE
For one profile, remove Kevin Companion from that profile's Mods selection.
For every profile, close the game and double-click "Disable Kevin.cmd". This
restores the original startup files while retaining Kevin's compatibility
package, mod entry and saved belongings. Run "Install Kevin.cmd" to enable him
again or install this release over a supported earlier preview. Keep the game
closed while updating; the installer checks the existing installation first.

Keep the game's .KevinLoader folder: it contains original-file backups and the
installation record. Do not delete KevinCompanion.u from a game with Kevin saves.
Disabling is supported; permanently removing his saved classes is not. The
installer and disable tool do not rewrite save files.

PREVIEW LIMITS
Standalone single-player only. Multiplayer, building jobs and direct control of
Kevin as the player character are not included. Movement and gathering are for
outdoor surface terrain; following pauses around bases and caves. Kevin does not
teleport to catch up. Terrain and obstacles may require repositioning or a new
order. This preview has not had a long public playtest across every terrain,
enemy, weapon or combination of mods.

The installer refuses unsupported game versions or conflicting file changes.
After a game update, use a Kevin release that supports the new game build.
Read PLAYER-GUIDE.txt for the player guide and VALIDATION.txt for the included
build's completed checks. CHECKSUMS.sha256 lists the release file checksums.

Kevin is an unofficial community mod and is not affiliated with Subsistence's
developer. Subsistence and its original assets belong to their respective owners.
This ZIP contains companion code, installer scripts and compact patches; you
need your own installed copy of the supported game.

WORKSHOP LINK
https://steamcommunity.com/sharedfiles/filedetails/?id=3816609201
Version 0.2.3 keeps the same Workshop item and gameplay as 0.2.2. Use the new
Setup for installation fixes; if Kevin already works, no gameplay update is
needed.
The installer is still required; subscribing alone does not install the code.

IF SETUP DOES NOT FINISH
Close Subsistence before installing or disabling Kevin. Select the Subsistence
folder that contains Binaries and UDKGame. If Windows denies access, use Retry
as administrator and approve the permission prompt. Canceling that prompt leaves
Setup open so you can retry later.

For a version/checksum mismatch, check the supported game version before trying
again. Keep the game's .KevinLoader backups if a previous Kevin installation
exists. Do not force installation over changed game files.

Click Save setup report... to save the result for troubleshooting. Setup also
keeps a report under %LOCALAPPDATA%\KevinCompanion\Logs. Reports contain your
local folder paths, so review them before posting them publicly. An unknown error
still needs its report; this release cannot promise to solve every PC's issue.
