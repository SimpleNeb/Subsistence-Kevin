[CmdletBinding()]
param([string]$OutputDirectory=(Join-Path $PSScriptRoot 'build'))
$ErrorActionPreference='Stop'
$out=[IO.Path]::GetFullPath($OutputDirectory)
if(Test-Path -LiteralPath $out){throw 'Choose a new output directory; existing output is preserved.'}
$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if(-not(Test-Path -LiteralPath $compiler)){$compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'}
if(-not(Test-Path -LiteralPath $compiler)){throw 'Install/enable Windows .NET Framework 4.8 development tools; no compiler was found.'}
$sources=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'authoring\verification') -File -Filter '*.cs'|Sort-Object Name|ForEach-Object FullName)+@('AuthorKeyStore.cs','JsonWriter.cs','ManifestAuthor.cs','Program.cs'|ForEach-Object{Join-Path $PSScriptRoot ('authoring\'+$_)})
[void][IO.Directory]::CreateDirectory($out)
$exe=Join-Path $out 'ModuleAuthoring.exe'
& $compiler /nologo /target:exe /langversion:5 /warnaserror+ /reference:System.Core.dll /reference:System.Security.dll ('/out:'+$exe) $sources
if($LASTEXITCODE-ne0){throw 'Authoring source compilation failed.'}
[ordered]@{compiled=$true;runtime='.NET Framework 4.8';language='C# 5';path=$exe;sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $exe).Hash.ToLowerInvariant();unrealScriptCompiled=$false}|ConvertTo-Json
