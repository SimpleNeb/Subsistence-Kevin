// A minimal community module. The framework owns the session boundary.
class CommunityHelloModule extends SimpleFrameworkModule;

function StartSession(WorldInfo NewWorld)
{
    LogInternal("COMMUNITY_HELLO_STARTED map=" $ NewWorld.GetMapName());
    // Create your own session objects here, after the player world is ready.
}

function EndSession()
{
    // Release your timers, callbacks, actors and world references here.
    LogInternal("COMMUNITY_HELLO_ENDED");
}
