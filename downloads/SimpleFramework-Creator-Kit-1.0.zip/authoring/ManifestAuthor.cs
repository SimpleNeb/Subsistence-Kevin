using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using SimpleFramework.Host.Verification;

namespace SimpleFramework.ModuleAuthoring {
    internal sealed class SigningResult {
        internal string EnvelopePath, ManifestDigest, KeyFingerprint, PublicPoint;
        internal int FileCount;internal bool ExactInputBytes;
    }
    internal static class ManifestAuthor {
        internal static SigningResult Sign(string keyDirectory,string contentDirectory,string templatePath,string outputPath,bool exact,string previousKeyDirectory) {
            string root=Path.GetFullPath(contentDirectory).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;
            AuthorKeyStore.NoLinks(root);Check.That(Directory.Exists(root),"SourceRoot","Content directory does not exist.");
            string output=Path.GetFullPath(outputPath);AuthorKeyStore.NoLinks(output);Check.That(!File.Exists(output)&&!Directory.Exists(output),"OutputExists","Output already exists; use a fresh staging directory.");
            byte[] original;AuthorKeyStore.NoLinks(templatePath);using(var input=new FileStream(templatePath,FileMode.Open,FileAccess.Read,FileShare.Read))original=SteamPublicationLookup.ReadBounded(input,524288);
            var draft=StrictJson.Object(StrictJson.Parse(original,524288));
            var handles=new Dictionary<string,FileStream>(StringComparer.OrdinalIgnoreCase);
            string temporary=null;
            try {
                var entries=StrictJson.Array(StrictJson.Get(draft,"files"),16384);long total=0;
                foreach(object entry in entries) {
                    var file=StrictJson.Object(entry);string relative=StrictJson.Text(StrictJson.Get(file,"path"),240);ManifestReader.RequirePath(relative);
                    Check.That(!handles.ContainsKey(relative),"FileOwnership","Duplicate file path.");
                    string source=Path.GetFullPath(Path.Combine(root,relative.Replace('/',Path.DirectorySeparatorChar)));
                    Check.That(source.StartsWith(root,StringComparison.OrdinalIgnoreCase)&&!source.Equals(output,StringComparison.OrdinalIgnoreCase),"SourcePath","Invalid source/output overlap.");
                    AuthorKeyStore.NoLinks(source);var stream=new FileStream(source,FileMode.Open,FileAccess.Read,FileShare.Read);handles.Add(relative,stream);
                    Check.That(stream.Length>0&&stream.Length<=536870912,"FileSize","Unsupported file size.");total=checked(total+stream.Length);Check.That(total<=536870912,"WorkLimit","Payload exceeds 512 MiB.");
                    string hash;using(var sha=SHA256.Create())hash=Signatures.Hex(sha.ComputeHash(stream));stream.Position=0;
                    if(exact)Check.That(StrictJson.Text(StrictJson.Get(file,"sha256"),64)==hash&&StrictJson.Integer(StrictJson.Get(file,"length"))==stream.Length,"FileDigest","Exact manifest does not match source bytes: "+relative);
                    else {file["sha256"]=hash;file["length"]=stream.Length;}
                }
                byte[] body=exact?original:JsonWriter.Bytes(draft);
                using(var key=AuthorKeyStore.Open(keyDirectory)) {
                    PayloadManifest manifest=ManifestReader.Read(body,key.Fingerprint);
                    byte[] signature=key.Sign(body);Check.That(Signatures.Verify(key.PublicPoint,body,signature),"Roundtrip","Generated manifest signature did not roundtrip.");
                    object rollover=null;
                    if(previousKeyDirectory!=null)using(var old=AuthorKeyStore.Open(previousKeyDirectory)) {
                        Check.That(old.Fingerprint!=key.Fingerprint,"KeyRollover","Old and new author keys must differ.");
                        byte[] message=Signatures.RolloverMessage(manifest,key.Fingerprint);byte[] authorization=old.Sign(message);
                        Check.That(Signatures.Verify(old.PublicPoint,message,authorization),"Roundtrip","Generated rollover did not roundtrip.");
                        rollover=new Dictionary<string,object>{{"publicKey",Convert.ToBase64String(old.PublicPoint)},{"signature",Convert.ToBase64String(authorization)}};
                    }
                    var envelope=new Dictionary<string,object>{{"format","simple-framework-envelope-v1"},{"publicKey",Convert.ToBase64String(key.PublicPoint)},{"manifest",Convert.ToBase64String(body)},{"signature",Convert.ToBase64String(signature)},{"rollover",rollover}};
                    byte[] bytes=JsonWriter.Bytes(envelope);Check.That(bytes.Length<=1048576,"EnvelopeSize","Envelope exceeds verifier limit.");
                    string parent=Path.GetDirectoryName(output);Check.That(Directory.Exists(parent),"OutputDirectory","Output parent does not exist.");
                    temporary=output+"."+Guid.NewGuid().ToString("N")+".tmp";
                    using(var stream=new FileStream(temporary,FileMode.CreateNew,FileAccess.Write,FileShare.None,4096,FileOptions.WriteThrough)){stream.Write(bytes,0,bytes.Length);stream.Flush(true);}
                    Roundtrip(File.ReadAllBytes(temporary),manifest.ManifestDigest,key.Fingerprint);
                    // Verify the held input again before the only visible commit.
                    foreach(OwnedFile file in manifest.Files){FileStream stream=handles[file.Path];stream.Position=0;string hash;using(var sha=SHA256.Create())hash=Signatures.Hex(sha.ComputeHash(stream));Check.That(stream.Length==file.Length&&hash==file.Sha256,"FileChanged","Source changed before commit.");}
                    File.Move(temporary,output);temporary=null;
                    return new SigningResult{EnvelopePath=output,ManifestDigest=manifest.ManifestDigest,KeyFingerprint=key.Fingerprint,PublicPoint=Convert.ToBase64String(key.PublicPoint),FileCount=manifest.Files.Count,ExactInputBytes=exact};
                }
            } finally {foreach(FileStream stream in handles.Values)stream.Dispose();if(temporary!=null&&File.Exists(temporary))File.Delete(temporary);}
        }
        internal static void Roundtrip(byte[] bytes,string expectedDigest,string expectedFingerprint) {
            var root=StrictJson.Object(StrictJson.Parse(bytes,1048576));StrictJson.Fields(root,"format","publicKey","manifest","signature","rollover");
            Check.That(StrictJson.Text(StrictJson.Get(root,"format"),64)=="simple-framework-envelope-v1","Roundtrip","Envelope format changed.");
            byte[] key=Signatures.Base64(StrictJson.Text(StrictJson.Get(root,"publicKey"),100),65,65);
            byte[] body=Signatures.Base64(StrictJson.Text(StrictJson.Get(root,"manifest"),700000),-1,524288);
            byte[] signature=Signatures.Base64(StrictJson.Text(StrictJson.Get(root,"signature"),100),64,64);
            Check.That(Signatures.Hash(key)==expectedFingerprint&&Signatures.Hash(body)==expectedDigest&&Signatures.Verify(key,body,signature),"Roundtrip","Written envelope differs from signed bytes.");
            ManifestReader.Read(body,expectedFingerprint);
        }
    }
}
