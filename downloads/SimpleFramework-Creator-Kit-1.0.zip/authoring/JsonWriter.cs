using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using SimpleFramework.Host.Verification;

namespace SimpleFramework.ModuleAuthoring {
    internal static class JsonWriter {
        internal static byte[] Bytes(object value){var output=new StringBuilder();Write(output,value);return new UTF8Encoding(false,true).GetBytes(output.ToString());}
        private static void Write(StringBuilder output,object value) {
            if(value==null){output.Append("null");return;}var text=value as string;if(text!=null){String(output,text);return;}
            if(value is bool){output.Append((bool)value?"true":"false");return;}
            var number=value as StrictJson.Number;if(number!=null){output.Append(number.Text);return;}
            if(value is int||value is long||value is uint||value is ulong){output.Append(Convert.ToString(value,CultureInfo.InvariantCulture));return;}
            var map=value as Dictionary<string,object>;if(map!=null){output.Append('{');var keys=new List<string>(map.Keys);keys.Sort(StringComparer.Ordinal);bool first=true;foreach(string key in keys){if(!first)output.Append(',');first=false;String(output,key);output.Append(':');Write(output,map[key]);}output.Append('}');return;}
            var list=value as System.Collections.IEnumerable;if(list!=null){output.Append('[');bool first=true;foreach(object item in list){if(!first)output.Append(',');first=false;Write(output,item);}output.Append(']');return;}
            throw new InvalidOperationException("Unsupported JSON value.");
        }
        private static void String(StringBuilder output,string value){output.Append('"');foreach(char c in value){switch(c){case '"':output.Append("\\\"");break;case '\\':output.Append("\\\\");break;case '\b':output.Append("\\b");break;case '\f':output.Append("\\f");break;case '\n':output.Append("\\n");break;case '\r':output.Append("\\r");break;case '\t':output.Append("\\t");break;default:if(c<32)output.Append("\\u"+((int)c).ToString("x4",CultureInfo.InvariantCulture));else output.Append(c);break;}}output.Append('"');}
    }
}
