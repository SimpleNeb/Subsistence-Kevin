using System;
using System.IO;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using SimpleFramework.Host.Verification;

namespace SimpleFramework.ModuleAuthoring {
    internal sealed class AuthorKey : IDisposable {
        private readonly CngKey key;
        internal readonly byte[] PublicPoint;
        internal string Fingerprint {get{return Signatures.Hash(PublicPoint);}}
        internal AuthorKey(CngKey value){key=value;byte[] blob=key.Export(CngKeyBlobFormat.EccPublicBlob);PublicPoint=new byte[65];PublicPoint[0]=4;Buffer.BlockCopy(blob,8,PublicPoint,1,64);}
        internal byte[] Sign(byte[] bytes){using(var signer=new ECDsaCng(key)){signer.HashAlgorithm=CngAlgorithm.Sha256;return signer.SignData(bytes);}}
        public void Dispose(){key.Dispose();}
    }
    internal static class AuthorKeyStore {
        internal const string KeyFile="author-key.dpapi.json";
        private static readonly byte[] Entropy=Encoding.UTF8.GetBytes("SimpleFramework.AuthorKeyStore.v1");
        internal static AuthorKey Generate(string directory) {
            string path=System.IO.Path.GetFullPath(directory);NoLinks(path);
            Check.That(!Directory.Exists(path)&&!File.Exists(path),"KeyExists","Choose a new private key directory.");
            SecurityIdentifier sid=WindowsIdentity.GetCurrent().User;
            var security=new DirectorySecurity();security.SetOwner(sid);security.SetAccessRuleProtection(true,false);
            security.AddAccessRule(new FileSystemAccessRule(sid,FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));
            Directory.CreateDirectory(path,security);CheckOwnerAcl(path,true);
            var options=new CngKeyCreationParameters();options.ExportPolicy=CngExportPolicies.AllowPlaintextExport;options.KeyUsage=CngKeyUsages.Signing;
            using(var generated=CngKey.Create(CngAlgorithm.ECDsaP256,null,options)) {
                byte[] plain=generated.Export(CngKeyBlobFormat.EccPrivateBlob);byte[] protectedBytes;
                try{protectedBytes=ProtectedData.Protect(plain,Entropy,DataProtectionScope.CurrentUser);}finally{Array.Clear(plain,0,plain.Length);}
                byte[] publicBlob=generated.Export(CngKeyBlobFormat.EccPublicBlob);byte[] point=new byte[65];point[0]=4;Buffer.BlockCopy(publicBlob,8,point,1,64);
                string json="{\"format\":\"simple-framework-author-key-v1\",\"ownerSid\":\""+sid.Value+"\",\"publicKey\":\""+Convert.ToBase64String(point)+"\",\"protectedPrivateBlob\":\""+Convert.ToBase64String(protectedBytes)+"\"}";
                byte[] bytes=Encoding.UTF8.GetBytes(json);string target=System.IO.Path.Combine(path,KeyFile);
                var fileSecurity=new FileSecurity();fileSecurity.SetOwner(sid);fileSecurity.SetAccessRuleProtection(true,false);fileSecurity.AddAccessRule(new FileSystemAccessRule(sid,FileSystemRights.FullControl,AccessControlType.Allow));
                using(var stream=new FileStream(target,FileMode.CreateNew,FileSystemRights.FullControl,FileShare.None,4096,FileOptions.WriteThrough,fileSecurity)){stream.Write(bytes,0,bytes.Length);stream.Flush(true);}
                CheckOwnerAcl(target,false);
            }
            return Open(path);
        }
        internal static AuthorKey Open(string directory) {
            string path=System.IO.Path.GetFullPath(directory);NoLinks(path);CheckOwnerAcl(path,true);
            string file=System.IO.Path.Combine(path,KeyFile);NoLinks(file);CheckOwnerAcl(file,false);
            byte[] bytes;using(var stream=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.Read))bytes=SteamPublicationLookup.ReadBounded(stream,16384);
            var json=StrictJson.Object(StrictJson.Parse(bytes,16384));StrictJson.Fields(json,"format","ownerSid","publicKey","protectedPrivateBlob");
            Check.That(StrictJson.Text(StrictJson.Get(json,"format"),64)=="simple-framework-author-key-v1","KeyFormat","Unsupported author key format.");
            Check.That(StrictJson.Text(StrictJson.Get(json,"ownerSid"),184)==WindowsIdentity.GetCurrent().User.Value,"KeyOwner","Author key belongs to another Windows user.");
            byte[] point=Signatures.Base64(StrictJson.Text(StrictJson.Get(json,"publicKey"),100),65,65);
            byte[] encrypted=Signatures.Base64(StrictJson.Text(StrictJson.Get(json,"protectedPrivateBlob"),12000),-1,8192);
            byte[] plain=null;AuthorKey result=null;
            try{plain=ProtectedData.Unprotect(encrypted,Entropy,DataProtectionScope.CurrentUser);result=new AuthorKey(CngKey.Import(plain,CngKeyBlobFormat.EccPrivateBlob));Check.That(Convert.ToBase64String(result.PublicPoint)==Convert.ToBase64String(point),"KeyBinding","Protected key differs from public key.");return result;}
            catch{if(result!=null)result.Dispose();throw;}
            finally{if(plain!=null)Array.Clear(plain,0,plain.Length);}
        }
        internal static void CheckOwnerAcl(string path,bool directory) {
            SecurityIdentifier sid=WindowsIdentity.GetCurrent().User;
            FileSystemSecurity security=directory?(FileSystemSecurity)Directory.GetAccessControl(path):(FileSystemSecurity)File.GetAccessControl(path);
            Check.That(security.GetOwner(typeof(SecurityIdentifier)).Equals(sid)&&security.AreAccessRulesProtected,"KeyAcl","Private key ACL must be protected and owned by this user.");
            bool ownerAccess=false;
            foreach(FileSystemAccessRule rule in security.GetAccessRules(true,true,typeof(SecurityIdentifier))) {
                if(rule.AccessControlType!=AccessControlType.Allow)continue;
                Check.That(rule.IdentityReference.Equals(sid),"KeyAcl","Private key grants access to another identity.");
                if((rule.FileSystemRights&FileSystemRights.FullControl)==FileSystemRights.FullControl)ownerAccess=true;
            }
            Check.That(ownerAccess,"KeyAcl","Private key owner lacks full control.");
        }
        internal static void NoLinks(string path){string current=System.IO.Path.GetFullPath(path);while(!string.IsNullOrEmpty(current)){if(File.Exists(current)||Directory.Exists(current))Check.That((File.GetAttributes(current)&FileAttributes.ReparsePoint)==0,"SourceLink","Linked author paths are not accepted.");current=System.IO.Path.GetDirectoryName(current);}}
    }
}
