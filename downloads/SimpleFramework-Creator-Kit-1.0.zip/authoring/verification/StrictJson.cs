using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace SimpleFramework.Host.Verification {
    // Bounded JSON reader: rejects duplicate keys and malformed Unicode before
    // semantic validation. Number tokens remain exact, never floating-point IDs.
    internal sealed class StrictJson {
        private readonly string text; private int at, nodes;
        private StrictJson(byte[] bytes, int maximum) {
            Check.That(bytes != null && bytes.Length > 0 && bytes.Length <= maximum, "JsonSize", "JSON size is invalid.");
            try { text = new UTF8Encoding(false, true).GetString(bytes); }
            catch (DecoderFallbackException) { throw new VerificationException("JsonUtf8", "Invalid UTF-8."); }
        }
        internal static object Parse(byte[] bytes, int maximum) {
            var parser=new StrictJson(bytes, maximum); object value=parser.Value(0); parser.White();
            Check.That(parser.at == parser.text.Length, "JsonTrailing", "Trailing JSON content."); return value;
        }
        private void White() { while (at<text.Length && (text[at]==' ' || text[at]=='\t' || text[at]=='\r' || text[at]=='\n')) at++; }
        private char Take() { Check.That(at<text.Length,"JsonSyntax","Truncated JSON."); return text[at++]; }
        private object Value(int depth) {
            Check.That(depth<=32 && ++nodes<=100000,"JsonLimit","JSON complexity limit exceeded."); White();
            Check.That(at<text.Length,"JsonSyntax","Missing JSON value."); char c=text[at];
            if(c=='"') return String();
            if(c=='{') { at++; var result=new Dictionary<string,object>(StringComparer.Ordinal); White(); if(at<text.Length && text[at]=='}'){at++;return result;}
                while(true){White(); Check.That(at<text.Length && text[at]=='"',"JsonSyntax","Expected object key."); string key=String(); White(); Check.That(Take()==':',"JsonSyntax","Expected colon.");
                    Check.That(!result.ContainsKey(key),"JsonDuplicate","Duplicate JSON key: "+key); result.Add(key,Value(depth+1)); White(); c=Take(); if(c=='}')return result; Check.That(c==',',"JsonSyntax","Expected object separator.");}
            }
            if(c=='[') { at++; var result=new List<object>(); White(); if(at<text.Length && text[at]==']'){at++;return result;}
                while(true){result.Add(Value(depth+1)); White(); c=Take(); if(c==']')return result;Check.That(c==',',"JsonSyntax","Expected array separator.");}
            }
            if(c=='t'){Literal("true");return true;} if(c=='f'){Literal("false");return false;} if(c=='n'){Literal("null");return null;}
            int start=at; if(c=='-')at++; Check.That(at<text.Length,"JsonSyntax","Missing number.");
            if(text[at]=='0')at++; else {Check.That(text[at]>='1'&&text[at]<='9',"JsonSyntax","Invalid number.");while(at<text.Length&&Digit(text[at]))at++;}
            if(at<text.Length&&text[at]=='.'){at++;int first=at;while(at<text.Length&&Digit(text[at]))at++;Check.That(at>first,"JsonSyntax","Invalid fraction.");}
            if(at<text.Length&&(text[at]=='e'||text[at]=='E')){at++;if(at<text.Length&&(text[at]=='+'||text[at]=='-'))at++;int first=at;while(at<text.Length&&Digit(text[at]))at++;Check.That(at>first,"JsonSyntax","Invalid exponent.");}
            Check.That(at-start<=64,"JsonLimit","Number too long.");return new Number(text.Substring(start,at-start));
        }
        private static bool Digit(char c){return c>='0'&&c<='9';}
        private void Literal(string expected) { for(int i=0;i<expected.Length;i++)Check.That(Take()==expected[i],"JsonSyntax","Invalid literal."); }
        private string String() {
            Check.That(Take()=='"',"JsonSyntax","Expected string."); var output=new StringBuilder();
            while(true){char c=Take(); if(c=='"')break;Check.That(c>=32,"JsonSyntax","Control character in string.");
                if(c=='\\'){c=Take();switch(c){case '"':case '\\':case '/':break;case 'b':c='\b';break;case 'f':c='\f';break;case 'n':c='\n';break;case 'r':c='\r';break;case 't':c='\t';break;case 'u':c=Unicode();break;default:throw new VerificationException("JsonSyntax","Invalid escape.");}}
                if(char.IsHighSurrogate(c)){output.Append(c);char low=Take();if(low=='\\'){Check.That(Take()=='u',"JsonUnicode","Missing low surrogate.");low=Unicode();}Check.That(char.IsLowSurrogate(low),"JsonUnicode","Invalid surrogate pair.");output.Append(low);}
                else {Check.That(!char.IsLowSurrogate(c),"JsonUnicode","Unexpected low surrogate.");output.Append(c);}
                Check.That(output.Length<=262144,"JsonLimit","String too large.");
            } return output.ToString();
        }
        private char Unicode(){int value=0;for(int i=0;i<4;i++){char c=Take();int digit=c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:c>='A'&&c<='F'?c-'A'+10:-1;Check.That(digit>=0,"JsonUnicode","Invalid Unicode escape.");value=value*16+digit;}return (char)value;}
        internal sealed class Number {internal readonly string Text;internal Number(string value){Text=value;}}
        internal static Dictionary<string,object> Object(object value){var result=value as Dictionary<string,object>;Check.That(result!=null,"JsonType","Expected object.");return result;}
        internal static List<object> Array(object value,int maximum){var result=value as List<object>;Check.That(result!=null&&result.Count<=maximum,"JsonType","Expected bounded array.");return result;}
        internal static object Get(Dictionary<string,object> value,string key){object result;Check.That(value.TryGetValue(key,out result),"JsonField","Missing field: "+key);return result;}
        internal static string Text(object value,int maximum){var result=value as string;Check.That(result!=null&&result.Length<=maximum,"JsonType","Expected bounded string.");return result;}
        internal static long Integer(object value){var number=value as Number;long result;Check.That(number!=null&&long.TryParse(number.Text,NumberStyles.AllowLeadingSign,CultureInfo.InvariantCulture,out result),"JsonType","Expected exact integer.");return long.Parse(number.Text,CultureInfo.InvariantCulture);}
        internal static ulong Id(object value){string token=value as string;var number=value as Number;if(token==null&&number!=null)token=number.Text;ulong result;Check.That(token!=null&&token.Length<=20&&ulong.TryParse(token,NumberStyles.None,CultureInfo.InvariantCulture,out result)&&result>0,"JsonType","Invalid Steam identifier.");return ulong.Parse(token,CultureInfo.InvariantCulture);}
        internal static bool Boolean(object value){Check.That(value is bool,"JsonType","Expected boolean.");return (bool)value;}
        internal static void Fields(Dictionary<string,object> value,params string[] allowed){var set=new HashSet<string>(allowed,StringComparer.Ordinal);foreach(string key in value.Keys)Check.That(set.Contains(key),"JsonField","Unknown field: "+key);}
    }
}
