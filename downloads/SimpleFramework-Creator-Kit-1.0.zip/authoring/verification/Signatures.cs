using System;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace SimpleFramework.Host.Verification {
    internal static class Signatures {
        internal static string Hash(byte[] bytes) {using(var sha=SHA256.Create())return Hex(sha.ComputeHash(bytes));}
        internal static string Hex(byte[] bytes){return BitConverter.ToString(bytes).Replace("-","").ToLowerInvariant();}
        internal static bool IsHash(string value){if(value==null||value.Length!=64)return false;foreach(char c in value)if(!((c>='0'&&c<='9')||(c>='a'&&c<='f')))return false;return true;}
        internal static byte[] Base64(string text,int exact,int maximum){byte[] result;try{result=Convert.FromBase64String(text);}catch(FormatException){throw new VerificationException("Encoding","Invalid base64.");}
            Check.That(result.Length<=maximum && (exact<0||result.Length==exact) && Convert.ToBase64String(result)==text,"Encoding","Noncanonical or oversized base64.");return result;}
        internal static bool Verify(byte[] point,byte[] data,byte[] signature) {
            Check.That(point.Length==65&&point[0]==4&&signature.Length==64,"Signature","P-256 key or signature has the wrong size.");
            // Windows BCRYPT_ECCPUBLIC_BLOB: ECDSA-P256 magic, 32-byte limbs, X/Y.
            byte[] blob=new byte[72];blob[0]=0x45;blob[1]=0x43;blob[2]=0x53;blob[3]=0x31;blob[4]=32;
            Buffer.BlockCopy(point,1,blob,8,64);
            try {using(var key=CngKey.Import(blob,CngKeyBlobFormat.EccPublicBlob))using(var ecdsa=new ECDsaCng(key)){ecdsa.HashAlgorithm=CngAlgorithm.Sha256;return ecdsa.VerifyData(data,signature);}}
            catch(CryptographicException){throw new VerificationException("Signature","Invalid P-256 author key or signature.");}
        }
        internal static Guid PublisherId(ulong owner) {
            // Stable UUIDv5 of the authoritative Steam account, not an untrusted
            // publisher UUID copied from the manifest.
            byte[] ns=new Guid("d31c8b6e-b457-50a8-944f-aa320713d87a").ToByteArray();Swap(ns);
            byte[] name=Encoding.UTF8.GetBytes("steam:"+owner.ToString(CultureInfo.InvariantCulture));byte[] input=new byte[ns.Length+name.Length];Buffer.BlockCopy(ns,0,input,0,ns.Length);Buffer.BlockCopy(name,0,input,ns.Length,name.Length);
            byte[] hash;using(var sha=SHA1.Create())hash=sha.ComputeHash(input);byte[] id=new byte[16];Buffer.BlockCopy(hash,0,id,0,16);id[6]=(byte)((id[6]&15)|80);id[8]=(byte)((id[8]&63)|128);Swap(id);return new Guid(id);
        }
        private static void Swap(byte[] b){byte t=b[0];b[0]=b[3];b[3]=t;t=b[1];b[1]=b[2];b[2]=t;t=b[4];b[4]=b[5];b[5]=t;t=b[6];b[6]=b[7];b[7]=t;}
        internal static byte[] RolloverMessage(PayloadManifest manifest,string fingerprint) {
            return Encoding.UTF8.GetBytes("SimpleFramework-KeyRollover-v1\n418030\n"+manifest.WorkshopId.ToString(CultureInfo.InvariantCulture)+"\n"+manifest.SteamOwnerId.ToString(CultureInfo.InvariantCulture)+"\n"+manifest.Id.ToString("D")+"\n"+fingerprint+"\n");
        }
    }
}
