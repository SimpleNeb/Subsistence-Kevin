using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace SimpleFramework.Host.Verification {
    internal static class ManifestReader {
        private static readonly Regex Name=new Regex("^[a-z][a-z0-9._-]{0,63}$",RegexOptions.CultureInvariant);
        private static readonly Regex Package=new Regex("^[A-Za-z_][A-Za-z0-9_]{0,127}$",RegexOptions.CultureInvariant);
        private static readonly Regex Device=new Regex("^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant);
        internal static PayloadManifest Read(byte[] bytes,string fingerprint) {
            var root=StrictJson.Object(StrictJson.Parse(bytes,524288));
            StrictJson.Fields(root,"format","appId","workshopId","steamOwnerId","payloadId","sequence","compatibilityTrack","hostMajor","minHostMinor","gameBuilds","files","modules","state","upgradeFrom","migrations");
            Check.That(Text(root,"format",64)=="simple-framework-manifest-v1","ManifestFormat","Unsupported manifest version.");
            Check.That(Int(root,"appId",1,int.MaxValue)==418030,"ManifestApp","Manifest is for another game.");
            ulong item=StrictJson.Id(StrictJson.Get(root,"workshopId")),owner=StrictJson.Id(StrictJson.Get(root,"steamOwnerId"));
            Guid id=Id(Text(root,"payloadId",36));long sequence=StrictJson.Integer(StrictJson.Get(root,"sequence"));Check.That(sequence>0,"ManifestSequence","Invalid release sequence.");
            string track=Named(Text(root,"compatibilityTrack",64));
            int major=Int(root,"hostMajor",1,65535),minor=Int(root,"minHostMinor",0,65535);
            var builds=Strings(StrictJson.Get(root,"gameBuilds"),16,64);Check.That(builds.Count>0,"ManifestBuild","No native build declared.");foreach(string hash in builds)RequireHash(hash);
            var files=new List<OwnedFile>();var paths=new HashSet<string>(StringComparer.OrdinalIgnoreCase);var packages=new HashSet<string>(StringComparer.OrdinalIgnoreCase);int totalClasses=0;
            foreach(object value in StrictJson.Array(StrictJson.Get(root,"files"),16384)) {
                var file=StrictJson.Object(value);StrictJson.Fields(file,"path","sha256","length","kind","packageName","savedClasses");
                string path=Text(file,"path",240);RequirePath(path);Check.That(paths.Add(path),"FileOwnership","Duplicate file path.");
                string hash=Text(file,"sha256",64);RequireHash(hash);long length=StrictJson.Integer(StrictJson.Get(file,"length"));
                Check.That(length>0 && length<=536870912,"FileSize","Unsupported declared file size.");string kind=Text(file,"kind",32);
                Check.That(kind=="unreal-package"||kind=="data"||kind=="state-migration","FileKind","Unsupported file kind.");
                object rawPackage=StrictJson.Get(file,"packageName");string package=rawPackage==null?null:StrictJson.Text(rawPackage,128);
                var classes=Strings(StrictJson.Get(file,"savedClasses"),4096,257);totalClasses+=classes.Count;Check.That(totalClasses<=16384,"WorkLimit","Too many saved classes.");
                if(kind=="unreal-package") {
                    Check.That(package!=null && Package.IsMatch(package) && path.EndsWith(".u",StringComparison.OrdinalIgnoreCase) && packages.Add(package),"PackageOwnership","Invalid or duplicate Unreal package.");
                    Check.That(string.Equals(path.Substring(path.LastIndexOf('/')+1),package+".u",StringComparison.OrdinalIgnoreCase),"PackageFileName","Unreal package filename must match its declared package name.");
                    foreach(string saved in classes)Check.That(saved.StartsWith(package+".",StringComparison.Ordinal)&&Package.IsMatch(saved.Substring(package.Length+1)),"SavedClass","Saved class is outside its package.");
                } else Check.That(package==null && classes.Count==0,"SavedClass","Only Unreal packages may declare saved classes.");
                files.Add(new OwnedFile(path,hash,length,kind,package,classes));
            }
            Check.That(files.Count>0,"ManifestFiles","Manifest has no files.");
            foreach(string path in paths){int slash=path.IndexOf('/');while(slash>=0){Check.That(!paths.Contains(path.Substring(0,slash)),"FileOwnership","A file is also a parent directory.");slash=path.IndexOf('/',slash+1);}}
            var modules=new List<Module>();var ids=new HashSet<Guid>();int requirements=0;
            foreach(object value in StrictJson.Array(StrictJson.Get(root,"modules"),4096)) {
                var module=StrictJson.Object(value);StrictJson.Fields(module,"id","nativeModId","entryClass","provides","requires");Guid moduleId=Id(Text(module,"id",36));Check.That(ids.Add(moduleId),"ModuleOwnership","Duplicate module identity.");
                Guid nativeModId=Id(Text(module,"nativeModId",36));object rawEntry=StrictJson.Get(module,"entryClass");string entryClass=rawEntry==null?null:StrictJson.Text(rawEntry,257);
                if(entryClass!=null){string[] parts=entryClass.Split('.');Check.That(parts.Length==2&&Package.IsMatch(parts[0])&&Package.IsMatch(parts[1])&&packages.Contains(parts[0]),"ModuleEntry","Entry class must name a package owned by this payload.");}
                var provides=new List<Capability>();var capabilityNames=new HashSet<string>(StringComparer.Ordinal);
                foreach(object cap in StrictJson.Array(StrictJson.Get(module,"provides"),64)) {var c=StrictJson.Object(cap);StrictJson.Fields(c,"name","major","minor");string name=Named(Text(c,"name",64));Check.That(capabilityNames.Add(name),"Capability","Duplicate capability.");provides.Add(new Capability(name,Int(c,"major",1,65535),Int(c,"minor",0,65535)));}
                var requires=new List<Requirement>();var dependencies=new HashSet<string>(StringComparer.Ordinal);
                foreach(object dep in StrictJson.Array(StrictJson.Get(module,"requires"),64)) {var d=StrictJson.Object(dep);StrictJson.Fields(d,"provider","capability","major","minMinor","optional");Guid provider=Id(Text(d,"provider",36));string name=Named(Text(d,"capability",64));Check.That(provider!=moduleId&&dependencies.Add(provider.ToString("D")+"/"+name),"Dependency","Invalid duplicate or self dependency.");requires.Add(new Requirement(provider,name,Int(d,"major",1,65535),Int(d,"minMinor",0,65535),StrictJson.Boolean(StrictJson.Get(d,"optional"))));}
                requirements+=requires.Count;Check.That(requirements<=32768,"WorkLimit","Too many requirements.");modules.Add(new Module(moduleId,nativeModId,entryClass,provides,requires));
            }
            Check.That(modules.Count>0,"ManifestModules","Manifest has no modules.");
            var state=StrictJson.Object(StrictJson.Get(root,"state"));StrictJson.Fields(state,"readMin","readMax","writes");
            var contract=new StateContract(Int(state,"readMin",1,int.MaxValue),Int(state,"readMax",1,int.MaxValue),Int(state,"writes",1,int.MaxValue));
            Check.That(contract.ReadMin<=contract.ReadMax&&contract.Writes>=contract.ReadMin&&contract.Writes<=contract.ReadMax,"StateSchema","Invalid state contract.");
            var predecessors=Strings(StrictJson.Get(root,"upgradeFrom"),256,64);foreach(string hash in predecessors){RequireHash(hash);Check.That(hash!=Signatures.Hash(bytes),"Predecessor","A manifest cannot precede itself.");}
            var migrations=new List<Migration>();var migrationKeys=new HashSet<string>(StringComparer.Ordinal);
            foreach(object value in StrictJson.Array(StrictJson.Get(root,"migrations"),256)) {
                var m=StrictJson.Object(value);StrictJson.Fields(m,"owner","fromManifest","fromSchema","toSchema","codePath","codeSha256");
                Guid migrationOwner=Id(Text(m,"owner",36));string from=Text(m,"fromManifest",64),path=Text(m,"codePath",240),hash=Text(m,"codeSha256",64);RequireHash(from);RequireHash(hash);RequirePath(path);
                int source=Int(m,"fromSchema",1,int.MaxValue),target=Int(m,"toSchema",1,int.MaxValue);bool found=false;
                foreach(OwnedFile file in files)if(file.Path==path&&file.Kind=="state-migration"&&file.Sha256==hash)found=true;
                Check.That(migrationOwner==id&&predecessors.Contains(from)&&target==contract.Writes&&target>=source&&found&&migrationKeys.Add(from+":"+source+":"+target),"Migration","Invalid or ambiguous owned migration.");
                migrations.Add(new Migration(migrationOwner,from,source,target,path,hash));
            }
            return new PayloadManifest(418030,item,owner,id,Signatures.PublisherId(owner),sequence,Signatures.Hash(bytes),fingerprint,track,major,minor,builds,files,modules,contract,predecessors,migrations);
        }
        internal static void RequirePath(string path) {
            Check.That(path.Length>0&&path.Length<=240&&path[0]!='/'&&path.IndexOf('\\')<0,"FilePath","Use a bounded relative slash path.");
            foreach(string segment in path.Split('/')) {
                Check.That(segment.Length>0&&segment!="."&&segment!=".."&&!segment.EndsWith(".",StringComparison.Ordinal)&&!segment.EndsWith(" ",StringComparison.Ordinal),"FilePath","Invalid path segment.");
                foreach(char c in segment)Check.That(c>=32&&c<=126&&":*?\"<>|".IndexOf(c)<0,"FilePath","Invalid path character.");
                Check.That(!Device.IsMatch(segment.Split('.')[0].TrimEnd(' ')),"FilePath","Reserved Windows path.");
            }
        }
        private static void RequireHash(string hash){Check.That(Signatures.IsHash(hash),"Digest","Invalid lowercase SHA256.");}
        private static string Named(string value){Check.That(Name.IsMatch(value),"ContractName","Invalid contract name.");return value;}
        private static Guid Id(string value){Guid result;Check.That(Guid.TryParseExact(value,"D",out result)&&result!=Guid.Empty&&result.ToString("D")==value,"Identity","Invalid canonical UUID.");return result;}
        private static string Text(Dictionary<string,object> value,string key,int max){return StrictJson.Text(StrictJson.Get(value,key),max);}
        private static int Int(Dictionary<string,object> value,string key,int min,int max){long result=StrictJson.Integer(StrictJson.Get(value,key));Check.That(result>=min&&result<=max,"ContractNumber","Contract number outside range.");return (int)result;}
        private static List<string> Strings(object value,int max,int maxString){var list=new List<string>();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);foreach(object item in StrictJson.Array(value,max)){string text=StrictJson.Text(item,maxString);Check.That(seen.Add(text),"DuplicateValue","Duplicate array value.");list.Add(text);}return list;}
    }
}
