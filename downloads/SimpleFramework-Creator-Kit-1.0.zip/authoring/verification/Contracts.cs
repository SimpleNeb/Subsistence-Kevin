using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;

namespace SimpleFramework.Host.Verification {
    public sealed class VerificationException : IOException {
        public readonly string Code;
        internal VerificationException(string code, string message) : base(message) { Code = code; }
    }
    internal static class Check {
        internal static void That(bool value, string code, string message) { if (!value) throw new VerificationException(code, message); }
    }
    public sealed class Capability {
        public readonly string Name; public readonly int Major, Minor;
        internal Capability(string name, int major, int minor) { Name=name; Major=major; Minor=minor; }
    }
    public sealed class Requirement {
        public readonly Guid Provider; public readonly string Name; public readonly int Major, MinMinor; public readonly bool Optional;
        internal Requirement(Guid provider, string name, int major, int minor, bool optional) { Provider=provider; Name=name; Major=major; MinMinor=minor; Optional=optional; }
    }
    public sealed class Module {
        public readonly Guid Id, NativeModId; public readonly string EntryClass;
        public readonly ReadOnlyCollection<Capability> Provides; public readonly ReadOnlyCollection<Requirement> Requires;
        internal Module(Guid id, Guid nativeModId, string entryClass, List<Capability> provides, List<Requirement> requires) { Id=id; NativeModId=nativeModId; EntryClass=entryClass; Provides=provides.AsReadOnly(); Requires=requires.AsReadOnly(); }
    }
    public sealed class OwnedFile {
        public readonly string Path, Sha256, Kind, PackageName; public readonly long Length; public readonly ReadOnlyCollection<string> SavedClasses;
        internal OwnedFile(string path, string hash, long length, string kind, string package, List<string> classes) { Path=path; Sha256=hash; Length=length; Kind=kind; PackageName=package; SavedClasses=classes.AsReadOnly(); }
    }
    public sealed class StateContract {
        public readonly int ReadMin, ReadMax, Writes;
        internal StateContract(int min, int max, int writes) { ReadMin=min; ReadMax=max; Writes=writes; }
    }
    public sealed class Migration {
        public readonly Guid Owner; public readonly string FromManifest, CodePath, CodeSha256; public readonly int FromSchema, ToSchema;
        internal Migration(Guid owner, string from, int fromSchema, int toSchema, string path, string hash) { Owner=owner; FromManifest=from; FromSchema=fromSchema; ToSchema=toSchema; CodePath=path; CodeSha256=hash; }
    }
    public sealed class PayloadManifest {
        public readonly uint AppId; public readonly ulong WorkshopId, SteamOwnerId;
        public readonly Guid Id, Publisher; public readonly long Sequence;
        public readonly string ManifestDigest, KeyFingerprint, CompatibilityTrack;
        public readonly int HostMajor, MinHostMinor;
        public readonly ReadOnlyCollection<string> GameBuilds, UpgradeFrom;
        public readonly ReadOnlyCollection<OwnedFile> Files; public readonly ReadOnlyCollection<Module> Modules;
        public readonly ReadOnlyCollection<Migration> Migrations; public readonly StateContract State;
        internal PayloadManifest(uint app, ulong item, ulong owner, Guid id, Guid publisher, long sequence, string digest, string key,
            string track, int major, int minor, List<string> builds, List<OwnedFile> files, List<Module> modules,
            StateContract state, List<string> predecessors, List<Migration> migrations) {
            AppId=app; WorkshopId=item; SteamOwnerId=owner; Id=id; Publisher=publisher; Sequence=sequence;
            ManifestDigest=digest; KeyFingerprint=key; CompatibilityTrack=track; HostMajor=major; MinHostMinor=minor;
            GameBuilds=builds.AsReadOnly(); Files=files.AsReadOnly(); Modules=modules.AsReadOnly(); State=state;
            UpgradeFrom=predecessors.AsReadOnly(); Migrations=migrations.AsReadOnly();
        }
    }
    // The host persists pins only as part of successful activation. These are
    // continuity state, never a substitute for current Steam evidence/signatures.
    public sealed class PublisherPin {
        public readonly ulong WorkshopId, SteamOwnerId; public readonly Guid PayloadId;
        public readonly string KeyFingerprint;
        public PublisherPin(ulong item, ulong owner, Guid payload, string key) { WorkshopId=item; SteamOwnerId=owner; PayloadId=payload; KeyFingerprint=key; }
    }
    // No public constructor and no JSON "verified" switch. Only the live HTTPS
    // lookup produces this object in the shipping library.
    public sealed class SteamPublication {
        public readonly ulong WorkshopId, SteamOwnerId; public readonly uint ConsumerAppId;
        public readonly string KeyFingerprint, ResponseSha256; public readonly DateTime CheckedUtc;
        internal SteamPublication(ulong item, ulong owner, uint app, string key, string hash, DateTime checkedUtc) {
            WorkshopId=item; SteamOwnerId=owner; ConsumerAppId=app; KeyFingerprint=key; ResponseSha256=hash; CheckedUtc=checkedUtc;
        }
    }
}
