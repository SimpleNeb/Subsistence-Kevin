using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;

namespace SimpleFramework.Host.Verification {
    public sealed class SteamPublicationLookup {
        public const string KeyTagPrefix="sfkey-v1-";
        private const string Endpoint="https://api.steampowered.com/ISteamRemoteStorage/GetPublishedFileDetails/v1/";
        public SteamPublication Lookup(ulong workshopId) {
            Check.That(workshopId>0,"WorkshopId","A Workshop item is required.");
            // Uses the framework's normal certificate validation. No supplied URL,
            // redirect, publisher secret, or certificate-validation bypass.
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var request=(HttpWebRequest)WebRequest.Create(Endpoint);
            request.AllowAutoRedirect=false;request.Method="POST";request.Timeout=10000;request.ReadWriteTimeout=10000;
            request.Proxy=WebRequest.DefaultWebProxy;
            byte[] body=Encoding.ASCII.GetBytes("itemcount=1&publishedfileids%5B0%5D="+workshopId.ToString(CultureInfo.InvariantCulture));
            request.ContentType="application/x-www-form-urlencoded";request.ContentLength=body.Length;
            using(var deadline=new Timer(delegate {request.Abort();},null,10000,Timeout.Infinite)) try {
                using(var output=request.GetRequestStream())output.Write(body,0,body.Length);
                using(var response=(HttpWebResponse)request.GetResponse()) {
                    Check.That(response.StatusCode==HttpStatusCode.OK && response.ResponseUri.AbsoluteUri==Endpoint,"SteamHttp","Unexpected Steam response or redirect.");
                    Check.That(response.ContentLength<=1048576,"SteamHttp","Steam response exceeds limit.");
                    using(var stream=response.GetResponseStream()) {
                        byte[] bytes=ReadBounded(stream,1048576);
                        return ParseResponse(bytes,workshopId,DateTime.UtcNow);
                    }
                }
            } catch(WebException error) { throw new VerificationException("SteamUnavailable","Steam identity lookup failed: "+error.Status); }
        }
        internal static byte[] ReadBounded(Stream stream,int maximum) {
            using(var result=new MemoryStream()) {byte[] buffer=new byte[8192];int count;while((count=stream.Read(buffer,0,buffer.Length))>0){Check.That(result.Length+count<=maximum,"ReadLimit","Input exceeds limit.");result.Write(buffer,0,count);}return result.ToArray();}
        }
        // Internal for deterministic adversarial tests, not a public trust adapter.
        internal static SteamPublication ParseResponse(byte[] bytes,ulong requested,DateTime now) {
            var root=StrictJson.Object(StrictJson.Parse(bytes,1048576));
            var response=StrictJson.Object(StrictJson.Get(root,"response"));
            var details=StrictJson.Array(StrictJson.Get(response,"publishedfiledetails"),1);
            Check.That(details.Count==1,"SteamIdentity","Steam did not return exactly one item.");
            var item=StrictJson.Object(details[0]);
            Check.That(StrictJson.Integer(StrictJson.Get(item,"result"))==1,"SteamIdentity","Workshop item lookup was not successful.");
            ulong id=StrictJson.Id(StrictJson.Get(item,"publishedfileid"));
            Check.That(id==requested,"SteamIdentity","Steam returned a different Workshop item.");
            Check.That(StrictJson.Integer(StrictJson.Get(item,"consumer_app_id"))==418030,"SteamIdentity","Workshop item belongs to another game.");
            ulong owner=StrictJson.Id(StrictJson.Get(item,"creator"));
            Check.That(StrictJson.Integer(StrictJson.Get(item,"banned"))==0,"SteamIdentity","Workshop item is unavailable.");
            var tags=StrictJson.Array(StrictJson.Get(item,"tags"),256);string fingerprint=null;
            foreach(object value in tags){var tag=StrictJson.Object(value);string text=StrictJson.Text(StrictJson.Get(tag,"tag"),255);
                if(!text.StartsWith(KeyTagPrefix,StringComparison.Ordinal))continue;
                string candidate=text.Substring(KeyTagPrefix.Length);
                Check.That(fingerprint==null && Signatures.IsHash(candidate),"SteamKeyBinding","Missing, duplicate or malformed author key tag.");fingerprint=candidate;
            }
            Check.That(fingerprint!=null,"SteamKeyBinding","This item has no Simple Framework author-key binding.");
            return new SteamPublication(id,owner,418030,fingerprint,Signatures.Hash(bytes),now);
        }
    }
}
