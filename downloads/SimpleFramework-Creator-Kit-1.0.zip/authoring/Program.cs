using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using SimpleFramework.Host.Verification;

namespace SimpleFramework.ModuleAuthoring {
    internal static class Program {
        private static int Main(string[] args) {
            try {
                if(args.Length==2&&args[0]=="keygen") {
                    using(var key=AuthorKeyStore.Generate(args[1]))Write(new Dictionary<string,object>{{"publicKey",Convert.ToBase64String(key.PublicPoint)},{"keyFingerprint",key.Fingerprint},{"workshopTag",SteamPublicationLookup.KeyTagPrefix+key.Fingerprint},{"privateKeyStored",true},{"privateKeyProtection","DPAPI CurrentUser and owner-only ACL"}});
                    return 0;
                }
                if(args.Length>=4&&(args[0]=="sign"||args[0]=="sign-exact")) {
                    string output=Path.Combine(args[2],"simple-framework.json"),oldKey=null;
                    for(int i=4;i<args.Length;i++){if(args[i]=="--output"&&i+1<args.Length)output=args[++i];else if(args[i]=="--rollover-from"&&i+1<args.Length)oldKey=args[++i];else throw new ArgumentException("Unknown or incomplete option.");}
                    SigningResult result=ManifestAuthor.Sign(args[1],args[2],args[3],output,args[0]=="sign-exact",oldKey);
                    Write(new Dictionary<string,object>{{"envelope",result.EnvelopePath},{"manifestDigest",result.ManifestDigest},{"keyFingerprint",result.KeyFingerprint},{"publicKey",result.PublicPoint},{"declaredFiles",result.FileCount},{"exactInputBytes",result.ExactInputBytes},{"localRoundtripVerified",true},{"steamPublicationVerified",false}});return 0;
                }
                Console.Error.WriteLine("Usage: ModuleAuthoring keygen <new-private-directory> | sign[-exact] <key-directory> <content-directory> <manifest-template> [--output <new-file>] [--rollover-from <old-key-directory>]");return 2;
            } catch(VerificationException error){Console.Error.WriteLine(error.Code+": "+error.Message);return 1;}
            catch(Exception error){Console.Error.WriteLine(error.GetType().Name+": "+error.Message);return 1;}
        }
        private static void Write(Dictionary<string,object> value){Console.WriteLine(Encoding.UTF8.GetString(JsonWriter.Bytes(value)));}
    }
}
