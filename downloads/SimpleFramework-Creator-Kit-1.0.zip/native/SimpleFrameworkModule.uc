// Public development contract v1. Session objects must not outlive their world.
// Implementations release their own world/actor references in EndSession.
class SimpleFrameworkModule extends Object abstract;

const API_MAJOR = 1;
const API_MINOR = 0;

var private WorldInfo SessionWorld;
var private bool bStarting;
var private bool bFinishing;
var private bool bFinishRequested;

final function WorldInfo GetSessionWorld()
{
    return SessionWorld;
}

final function bool BeginSession(WorldInfo NewWorld)
{
    if (NewWorld == none || bStarting || bFinishing) { return false; }
    if (SessionWorld == NewWorld) { return true; }
    if (SessionWorld != none) { return false; }
    SessionWorld = NewWorld;
    bStarting = true;
    StartSession(NewWorld);
    bStarting = false;
    if (bFinishRequested) { FinishSession(); }
    return SessionWorld == NewWorld;
}

final function FinishSession()
{
    if (SessionWorld == none || bFinishing) { return; }
    if (bStarting) { bFinishRequested = true; return; }
    bFinishRequested = false;
    bFinishing = true;
    EndSession();
    SessionWorld = none;
    bFinishing = false;
}

function StartSession(WorldInfo NewWorld) {}
function EndSession() {}
